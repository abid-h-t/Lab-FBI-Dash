"""
app.py - Entry point of the FBI Homicide Explorer (CSC464/664 Dash lab).

Run it (with the virtual environment activated):
    python app.py            -> http://127.0.0.1:8050   (presentation mode)
    python app.py --debug    -> same, plus Dash dev tools and auto-reload

Project structure
    app.py              this file: creates the Dash app and starts the web server
    src/data_prep.py    raw FBI files -> clean pandas DataFrame (cached CSV)
    src/theme.py        colors and shared chart styling (light + dark)
    src/charts.py       one function per visualization (+ insight text)
    src/layout.py       page structure: header, filters, KPI cards, tabs
    src/callbacks.py    interactivity: filters -> charts, map click, reset, download
    assets/             CSS + logos; Dash serves this folder automatically
    data/               raw FBI zip files + the cleaned CSV
"""
import sys

from dash import Dash

from src.callbacks import register_callbacks
from src.data_prep import load_data
from src.layout import build_layout

# 1. Load the cleaned data once, when the server starts (cleans raw files if needed)
df, report = load_data()

# 2. Create the app. Every file in assets/ (style.css, logos) is loaded automatically.
app = Dash(__name__, title="FBI Homicide Explorer · LSUS", update_title=None)
app.layout = build_layout(df, report)

# 3. Wire up all the interactive behaviour
register_callbacks(app, df, report)

server = app.server   # the underlying Flask server (useful for deployment)

if __name__ == "__main__":
    debug = "--debug" in sys.argv
    print(f"Loaded {len(df):,} incidents. Open http://127.0.0.1:8050 in your browser (Ctrl+C to stop).")
    app.run(host="127.0.0.1", port=8050, debug=debug)
