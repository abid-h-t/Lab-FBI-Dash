"""
layout.py - The page structure (what goes where). No logic lives here;
callbacks.py fills the figures and numbers in.

    +------------------------------------------------------------------+
    |  [LSUS logo]   FBI Homicide Explorer 2015-2024   [FBI badge] [☾] |  header
    +--------------+---------------------------------------------------+
    |  FILTERS     |  KPI cards                                        |
    |  years       |  +---------------------------------------------+  |
    |  regions     |  | Tabs: Overview | H1 | H2 | H3 | H4 | H5 | Data|  |
    |  states      |  |   hypothesis card + chart controls          |  |
    |  weapons     |  |   chart                                     |  |
    |  victim sex  |  |   "what the current selection shows"        |  |
    |  victim age  |  +---------------------------------------------+  |
    |  reset / csv |                                                   |
    +--------------+---------------------------------------------------+
"""
from __future__ import annotations

from dash import dcc, html

from .charts import DIMENSIONS, H5_METRICS, MAP_METRICS
from .data_prep import REGION_ORDER, WEAPON_ORDER, UNKNOWN

GRAPH_CONFIG = {"displaylogo": False, "responsive": True,
                "toImageButtonOptions": {"format": "png", "scale": 2, "filename": "fbi_dashboard_chart"}}


# ---------------------------------------------------------------------------
# small building blocks
# ---------------------------------------------------------------------------
def control(label: str, component, hint: str | None = None) -> html.Div:
    """A labelled control (label on top, optional hint underneath)."""
    children = [html.Label(label, className="control-label"), component]
    if hint:
        children.append(html.Div(hint, className="control-hint"))
    return html.Div(children, className="control")


def graph(graph_id: str) -> dcc.Loading:
    return dcc.Loading(dcc.Graph(id=graph_id, config=GRAPH_CONFIG), type="dot",
                       color="#EAAA00", delay_show=250)


def insight_box(insight_id: str) -> html.Div:
    return html.Div([html.Div("What the current selection shows", className="insight-title"),
                     html.Ul(id=insight_id, className="insight-list")], className="insight")


def hypothesis_card(num: int, tag: str, title: str, statement: str, test: str,
                    controls: list, graph_id: str) -> html.Div:
    return html.Div([
        html.Div([html.Span(f"H{num}", className="h-badge"), html.Span(tag, className="h-tag")],
                 className="h-head"),
        html.H2(title, className="h-title"),
        html.P(statement, className="h-statement"),
        html.Details([html.Summary("How this chart tests it"), html.P(test)], className="h-test"),
        html.Div(controls, className="chart-controls"),
        graph(graph_id),
        insight_box(f"{graph_id}-insight"),
    ], className="card")


# ---------------------------------------------------------------------------
# header / sidebar / footer
# ---------------------------------------------------------------------------
def header() -> html.Header:
    return html.Header([
        html.Div([
            html.Img(src="/assets/lsus_logo.png", alt="LSUS logo", className="logo lsus-light"),
            html.Img(src="/assets/lsus_cs_gw.png", alt="LSUS Computer Science logo", className="logo lsus-dark"),
        ], className="logo-wrap"),
        html.Div([
            html.H1("FBI Homicide Explorer"),
            html.P("Supplementary Homicide Reports · United States · 2015–2024 · "
                   "CSC464/664 Information Visualization"),
        ], className="titles"),
        html.Div([
            html.Img(src="/assets/fbi_badge.svg", alt="FBI crime data badge", className="logo badge"),
            html.Button("☾ Dark", id="theme-btn", className="btn btn-ghost", n_clicks=0,
                        title="Switch light / dark theme"),
        ], className="header-right"),
    ], className="header")


def sidebar(df) -> html.Aside:
    y0, y1 = int(df["year"].min()), int(df["year"].max())
    states = sorted(df["state"].cat.categories)
    return html.Aside([
        html.Div("Filters", className="side-title"),
        html.P("Every chart and number on the page responds to these.", className="side-sub"),
        control("Years", dcc.RangeSlider(
            id="year-slider", min=y0, max=y1, step=1, value=[y0, y1], allowCross=False,
            marks={y: f"’{str(y)[2:]}" for y in range(y0, y1 + 1)},
            tooltip={"placement": "bottom", "always_visible": False})),
        control("Census region", dcc.Checklist(
            id="region-check", options=REGION_ORDER, value=REGION_ORDER,
            className="checklist", inputClassName="check-input", labelClassName="check-label")),
        control("States", dcc.Dropdown(
            id="state-dd", options=states, value=[], multi=True,
            placeholder="All states (or click the map)"),
            "Only states in the selected regions are listed."),
        control("Weapon", dcc.Dropdown(
            id="weapon-dd", options=WEAPON_ORDER + [UNKNOWN], value=[], multi=True,
            placeholder="All weapons")),
        control("Victim sex", dcc.Checklist(
            id="sex-check", options=["Male", "Female", UNKNOWN], value=["Male", "Female", UNKNOWN],
            className="checklist", inputClassName="check-input", labelClassName="check-label")),
        control("Victim age", dcc.RangeSlider(
            id="age-slider", min=0, max=99, step=1, value=[0, 99], allowCross=False,
            marks={a: str(a) for a in (0, 18, 25, 35, 50, 65, 99)},
            tooltip={"placement": "bottom", "always_visible": False}),
            "Full range also keeps cases with unknown age."),
        html.Div([
            html.Button("↺ Reset", id="reset-btn", className="btn btn-ghost", n_clicks=0),
            html.Button("⤓ Download CSV", id="download-btn", className="btn btn-primary", n_clicks=0),
        ], className="btn-row"),
        dcc.Download(id="download"),
        html.Div(id="filter-summary", className="filter-summary"),
    ], className="sidebar")


def footer(report: dict) -> html.Footer:
    return html.Footer([
        html.Span("Data: FBI Uniform Crime Reporting Program - Supplementary Homicide Reports "
                  "(Crime Data Explorer, cde.ucr.cjis.gov). "),
        html.Span(f"{report['rows_kept']:,} murder & non-negligent manslaughter incidents "
                  f"(first victim / first offender of each incident). "),
        html.Span("Built with Dash by Plotly · Abid Talukder · LSUS Computer Science."),
    ], className="footer")


# ---------------------------------------------------------------------------
# tabs
# ---------------------------------------------------------------------------
def overview_tab() -> html.Div:
    return html.Div([
        html.Div([
            html.Div([
                html.Div([html.H2("Where do homicides happen?", className="h-title"),
                          dcc.Dropdown(id="map-metric", options=[{"label": v, "value": k}
                                                                  for k, v in MAP_METRICS.items()],
                                       value="n", clearable=False, className="inline-dd")],
                         className="card-head"),
                graph("map-graph"),
                insight_box("map-graph-insight"),
            ], className="card"),
            html.Div([
                html.Div([html.H2("When do they happen?", className="h-title"),
                          dcc.RadioItems(id="trend-mode", options=[
                              {"label": "Timeline", "value": "time"},
                              {"label": "Seasonality", "value": "season"}],
                              value="time", className="segmented", inputClassName="seg-input",
                              labelClassName="seg-label")],
                         className="card-head"),
                graph("trend-graph"),
                insight_box("trend-graph-insight"),
            ], className="card"),
        ], className="grid-2"),
    ])


def h_tabs() -> list:
    """The five hypothesis tabs (title, statement, how it is tested, controls)."""
    return [
        dcc.Tab(label="H1 · Gun surge", value="h1", className="tab", selected_className="tab--sel",
                children=hypothesis_card(
                    1, "Time × Weapon × Region",
                    "The 2020–21 homicide surge was a gun surge, and it hit regions unequally",
                    "Between 2019 and 2021 firearm homicides grew much faster than homicides with any "
                    "other weapon, so the firearm share went up. The rise was not uniform: the Northeast, "
                    "which had the lowest firearm share before 2020, jumped the most, while the South and "
                    "West changed far less.",
                    "Each cell is one region in one year. Choose 'Change vs first year' to see the rise "
                    "in percentage points (red = up, blue = down). If the hypothesis is right, the 2020 "
                    "and 2021 columns turn red, with the Northeast row reddest.",
                    [control("Show", dcc.RadioItems(
                        id="h1-metric", value="share", className="segmented", inputClassName="seg-input",
                        labelClassName="seg-label", options=[
                            {"label": "Firearm share %", "value": "share"},
                            {"label": "Change vs first year", "value": "change"},
                            {"label": "Incident count", "value": "count"}]))],
                    "h1-graph")),
        dcc.Tab(label="H2 · Who kills whom", value="h2", className="tab", selected_className="tab--sel",
                children=hypothesis_card(
                    2, "Victim sex × Relationship × Weapon",
                    "Who kills depends on who dies",
                    "Female victims are killed mainly by intimate partners and family members, while male "
                    "victims are killed mainly by acquaintances and strangers. The weapon (or circumstance) "
                    "inside each relationship also differs by victim sex.",
                    "Inner ring = victim sex, middle ring = offender's relationship to the victim, outer "
                    "ring = weapon or circumstance. The percentages are 'share of the parent ring', so you "
                    "can compare the blue Intimate-partner slice under Female with the one under Male.",
                    [control("Outer ring", dcc.RadioItems(
                        id="h2-outer", value="weapon_group", className="segmented", inputClassName="seg-input",
                        labelClassName="seg-label", options=[
                            {"label": "Weapon", "value": "weapon_group"},
                            {"label": "Circumstance", "value": "circ_group"}])),
                     control("Unknowns", dcc.Checklist(
                         id="h2-unknown", options=[{"label": " Show 'Unknown' slices", "value": "y"}],
                         value=[], className="checklist", inputClassName="check-input",
                         labelClassName="check-label"))],
                    "h2-graph")),
        dcc.Tab(label="H3 · How it happens", value="h3", className="tab", selected_className="tab--sel",
                children=hypothesis_card(
                    3, "Relationship × Circumstance × Weapon",
                    "Social distance decides how a killing happens",
                    "The closer the relationship, the less often a gun is used: stranger killings are the "
                    "most gun-heavy and about twice as likely to happen during a felony (robbery, burglary, "
                    "drugs) as family killings, while family killings use firearms in fewer than half of "
                    "cases and rely much more on hands/feet, blunt objects and other weapons. "
                    "Intimate-partner killings start overwhelmingly from arguments.",
                    "Each vertical axis is one variable; ribbons show how many incidents move from one "
                    "category to the next. Ribbons are colored by the first axis. If the hypothesis holds, "
                    "the yellow Stranger ribbons end mostly at Handgun / Other firearm and touch Felony "
                    "more often, the orange Family ribbons spread out to the non-gun weapons, and the blue "
                    "Intimate-partner ribbons pour into Argument.",
                    [control("Axes (in order)", dcc.Dropdown(
                        id="h3-dims", multi=True, value=["rel_group", "circ_group", "weapon_group"],
                        options=[{"label": v[0], "value": k} for k, v in DIMENSIONS.items()],
                        className="wide-dd")),
                     control("Unknowns", dcc.Checklist(
                         id="h3-unknown", options=[{"label": " Show 'Unknown' categories", "value": "y"}],
                         value=[], className="checklist", inputClassName="check-input",
                         labelClassName="check-label"))],
                    "h3-graph")),
        dcc.Tab(label="H4 · Age gap", value="h4", className="tab", selected_className="tab--sel",
                children=hypothesis_card(
                    4, "Offender age × Victim age × Relationship",
                    "The relationship sets the age gap between killer and victim",
                    "Intimate-partner killings involve people of nearly the same age and gang killings are "
                    "young-on-young, but family killings show a two-humped age gap: parents killing "
                    "children (offender much older) and adult children killing parents (offender much "
                    "younger).",
                    "Each violin is the distribution of 'offender age minus victim age' (0 = same age, "
                    "positive = offender older). Wide = many cases at that gap. A two-humped Family violin "
                    "and a narrow Intimate-partner violin support the hypothesis.",
                    [control("Group by", dcc.RadioItems(
                        id="h4-group", value="rel_group", className="segmented", inputClassName="seg-input",
                        labelClassName="seg-label", options=[
                            {"label": "Relationship", "value": "rel_group"},
                            {"label": "Circumstance", "value": "circ_group"}])),
                     control("Split", dcc.Checklist(
                         id="h4-split", options=[{"label": " Split by victim sex", "value": "y"}],
                         value=["y"], className="checklist", inputClassName="check-input",
                         labelClassName="check-label"))],
                    "h4-graph")),
        dcc.Tab(label="H5 · Guns & youth", value="h5", className="tab", selected_className="tab--sel",
                children=hypothesis_card(
                    5, "State geography × Weapon × Victim age",
                    "Where guns dominate, the victims are younger",
                    "States where a larger share of homicides are committed with firearms have younger "
                    "victims. The relationship also holds inside every Census region, so it is not simply "
                    "a 'South versus the rest' effect.",
                    "One bubble per state (size = incidents). A downward dashed trend line and negative "
                    "correlations (r) inside each region support the hypothesis. Use the slider to drop "
                    "states with few incidents, whose numbers are noisy.",
                    [control("Y axis", dcc.Dropdown(
                        id="h5-y", value="age", clearable=False, className="inline-dd",
                        options=[{"label": v, "value": k} for k, v in H5_METRICS.items()])),
                     control("Minimum incidents per state", dcc.Slider(
                         id="h5-min", min=0, max=1000, step=50, value=100,
                         marks={v: str(v) for v in (0, 250, 500, 750, 1000)},
                         tooltip={"placement": "bottom"}), None)],
                    "h5-graph")),
    ]


def data_tab(report: dict) -> html.Div:
    r = report
    steps = [
        f"Read 10 raw FBI SHR master files (2015–2024, fixed-width text inside zip files): "
        f"{r['rows_read']:,} records.",
        "Cut each 268-character record into columns using the FBI record layout "
        "(state, month, ages, sex, race, weapon, relationship, circumstance …).",
        "Decoded FBI codes into labels and grouped detailed codes into analysis groups "
        "(e.g. 30+ relationship codes → Intimate partner / Family / Acquaintance / Stranger).",
        f"Removed {r['dropped_negligent_manslaughter']:,} negligent-manslaughter records "
        f"(homicide type B - accidents, not murders).",
        f"Removed {r['dropped_bad_state_or_month']:,} records with a territory / invalid state or month code.",
        "Ages: 'NB'/'BB' (newborn/baby) → 0, '00' (unknown) → missing, impossible values → missing.",
        "Missing categories are kept as an explicit 'Unknown' level instead of being deleted, so the "
        "charts can show or hide them on purpose (see the toggles in H2 and H3).",
        f"{r['exact_duplicate_rows']:,} rows look identical but were kept: separate incidents in the "
        "same agency and month can share all coded fields.",
        "Derived columns: firearm flag, weapon class, offender−victim age gap, victim age band, date.",
        f"Result: {r['rows_kept']:,} clean incidents, cached in data/shr_clean.csv.",
        "Caveat: SHR reporting is voluntary and coverage differs by state and year (e.g. Florida sent almost "
        "no SHR records before 2021), so the hypotheses compare shares and medians rather than raw counts.",
    ]
    return html.Div([
        html.Div([
            html.Div([
                html.H2("How the data was cleaned", className="h-title"),
                html.Ol([html.Li(s) for s in steps], className="steps"),
            ], className="card"),
            html.Div([
                html.H2("How much is missing?", className="h-title"),
                html.P("Share of records where a field is unknown after cleaning. Offender fields are "
                       "missing in about a third of cases, mostly because no offender was identified, "
                       "so offender-based charts describe solved cases only.", className="h-statement"),
                graph("missing-graph"),
            ], className="card"),
        ], className="grid-2"),
    ])


# ---------------------------------------------------------------------------
# the whole page
# ---------------------------------------------------------------------------
def build_layout(df, report) -> html.Div:
    return html.Div([
        dcc.Store(id="theme-store", data="light", storage_type="local"),
        header(),
        html.Div([
            sidebar(df),
            html.Main([
                html.Div(id="kpi-row", className="kpi-row"),
                dcc.Tabs(id="tabs", value="overview", className="tabs", children=[
                    dcc.Tab(label="Overview", value="overview", className="tab",
                            selected_className="tab--sel", children=overview_tab()),
                    *h_tabs(),
                    dcc.Tab(label="Data & method", value="data", className="tab",
                            selected_className="tab--sel", children=data_tab(report)),
                ]),
            ], className="main"),
        ], className="body"),
        footer(report),
    ], id="app-root", className="theme-light")
