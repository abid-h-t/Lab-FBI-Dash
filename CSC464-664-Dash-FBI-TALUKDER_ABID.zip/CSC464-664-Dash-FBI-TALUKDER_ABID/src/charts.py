"""
charts.py - Every figure in the dashboard, one function per chart.

Each function takes the *already filtered* DataFrame plus the chart's own
control values and the theme ("light" / "dark"), and returns
    (figure, insights)
where `insights` is a short list of sentences computed from the same data,
so the text under each chart always describes exactly what is on screen.

Visualization types (each one is used exactly ONCE in the dashboard):
    Overview  - choropleth map ............ fig_map
    Overview  - line chart ................ fig_trend
    H1        - annotated heatmap ......... fig_h1_heatmap
    H2        - sunburst .................. fig_h2_sunburst
    H3        - parallel categories ....... fig_h3_parcats
    H4        - split violin plot ......... fig_h4_violin
    H5        - bubble scatter + fit line . fig_h5_scatter
    Data tab  - horizontal bar chart ...... fig_missing_bar
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from .data_prep import (CIRC_ORDER, MONTH_NAMES, REGION_ORDER, REL_ORDER, SEX_ORDER,
                        UNKNOWN, WEAPON_ORDER, AGE_BANDS)
from .theme import (CHROME, UNKNOWN_GRAY, color_map, div_scale, empty_figure,
                    seq_scale, style)

# Human-readable names and fixed category orders for every categorical column
DIMENSIONS = {
    "rel_group":       ("Relationship", REL_ORDER),
    "circ_group":      ("Circumstance", CIRC_ORDER),
    "weapon_group":    ("Weapon", WEAPON_ORDER),
    "victim_sex":      ("Victim sex", SEX_ORDER),
    "offender_sex":    ("Offender sex", SEX_ORDER),
    "region":          ("Region", REGION_ORDER),
    "victim_age_band": ("Victim age", [b[2] for b in AGE_BANDS]),
}
REGION_SYMBOLS = {"Northeast": "circle", "Midwest": "square", "South": "diamond", "West": "triangle-up"}


def _pct(x: float) -> str:
    return f"{x * 100:.1f}%"


def _rgba(hex_color: str, alpha: float) -> str:
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alpha})"


# ===========================================================================
# KPI CARDS
# ===========================================================================
def kpis(dff: pd.DataFrame, full: pd.DataFrame) -> list[dict]:
    """Headline numbers for the selection, each compared with the full dataset."""
    def calc(d):
        known_sex = d[d["victim_sex"] != UNKNOWN]
        return {
            "n": len(d),
            "fa": d["firearm"].mean() if len(d) else np.nan,
            "age": d["victim_age"].median() if len(d) else np.nan,
            "female": (known_sex["victim_sex"] == "Female").mean() if len(known_sex) else np.nan,
            "unk_off": (d["offender_sex"] == UNKNOWN).mean() if len(d) else np.nan,
        }
    s, a = calc(dff), calc(full)
    fmt_pct = lambda v: "-" if pd.isna(v) else _pct(v)
    fmt_age = lambda v: "-" if pd.isna(v) else f"{v:.0f} yrs"
    return [
        {"label": "Homicide incidents", "value": f"{s['n']:,}",
         "sub": f"{s['n'] / a['n']:.0%} of all {a['n']:,} records"},
        {"label": "Firearm share", "value": fmt_pct(s["fa"]), "sub": f"all data: {fmt_pct(a['fa'])}"},
        {"label": "Median victim age", "value": fmt_age(s["age"]), "sub": f"all data: {fmt_age(a['age'])}"},
        {"label": "Female victims", "value": fmt_pct(s["female"]), "sub": f"all data: {fmt_pct(a['female'])}"},
        {"label": "Offender unknown", "value": fmt_pct(s["unk_off"]),
         "sub": "proxy for unsolved cases"},
    ]


# ===========================================================================
# OVERVIEW 1 - CHOROPLETH MAP  (click a state to filter the whole dashboard)
# ===========================================================================
MAP_METRICS = {
    "n": "Homicide incidents",
    "fa": "Firearm share (%)",
    "age": "Median victim age",
    "female": "Female victims (%)",
}


def fig_map(dff: pd.DataFrame, metric: str, selected_states: list, theme: str):
    if dff.empty:
        return empty_figure(theme), []
    g = dff.groupby("state", observed=True).agg(
        n=("firearm", "size"), fa=("firearm", "mean"), age=("victim_age", "median"),
        female=("victim_sex", lambda s: (s == "Female").mean())).reset_index()
    g["fa"] *= 100
    g["female"] *= 100
    fig = px.choropleth(
        g, locations="state", locationmode="USA-states", scope="usa", color=metric,
        color_continuous_scale=seq_scale(theme),
        custom_data=["n", "fa", "age", "female"],
        labels={metric: MAP_METRICS[metric]})
    fig.update_traces(
        marker_line_color=CHROME[theme]["surface"], marker_line_width=1,
        hovertemplate="<b>%{location}</b><br>Incidents: %{customdata[0]:,}"
                      "<br>Firearm share: %{customdata[1]:.1f}%"
                      "<br>Median victim age: %{customdata[2]:.0f}"
                      "<br>Female victims: %{customdata[3]:.1f}%<extra></extra>")
    if selected_states:   # outline the states that are currently selected
        fig.add_trace(go.Choropleth(
            locations=selected_states, z=[1] * len(selected_states), locationmode="USA-states",
            colorscale=[[0, "rgba(0,0,0,0)"], [1, "rgba(0,0,0,0)"]], showscale=False,
            marker_line_color="#EAAA00", marker_line_width=3, hoverinfo="skip"))
    fig.update_geos(bgcolor="rgba(0,0,0,0)", lakecolor="rgba(0,0,0,0)",
                    landcolor=CHROME[theme]["grid"], showlakes=False)
    fig.update_layout(coloraxis_colorbar=dict(title=dict(text=MAP_METRICS[metric], side="right"),
                                              thickness=12, len=0.8))
    style(fig, theme, height=420, legend=False)
    fig.update_layout(margin=dict(l=0, r=0, t=8, b=0), clickmode="event")

    top = g.sort_values(metric, ascending=False).head(3)
    unit = "" if metric in ("n", "age") else "%"
    insights = [f"Highest {MAP_METRICS[metric].lower()}: " +
                ", ".join(f"{r.state} ({getattr(r, metric):,.1f}{unit})" if metric != "n"
                          else f"{r.state} ({int(r.n):,})" for r in top.itertuples()),
                "Click a state to add or remove it from the State filter (gold outline = selected)."]
    return fig, insights


# ===========================================================================
# OVERVIEW 2 - LINE CHART (timeline or seasonality, firearm vs other)
# ===========================================================================
def fig_trend(dff: pd.DataFrame, mode: str, theme: str):
    if dff.empty:
        return empty_figure(theme), []
    cmap = color_map(["Firearm", "Other weapon"], theme)
    if mode == "season":
        n_years = dff["year"].nunique()
        g = dff.groupby(["month", "weapon_class"], observed=True).size().div(n_years).reset_index(name="n")
        x, xtitle, ytitle = "month", "Month of year", "Average incidents per month"
    else:
        g = dff.groupby(["date", "weapon_class"], observed=True).size().reset_index(name="n")
        x, xtitle, ytitle = "date", "Month", "Incidents per month"
    fig = px.line(g, x=x, y="n", color="weapon_class", color_discrete_map=cmap,
                  category_orders={"weapon_class": ["Firearm", "Other weapon"]},
                  labels={"n": ytitle, x: xtitle, "weapon_class": "Weapon"})
    fig.update_traces(line_width=2, mode="lines+markers" if mode == "season" else "lines",
                      marker_size=8,
                      hovertemplate="%{y:,.0f} incidents<extra>%{fullData.name}</extra>")
    if mode == "season":
        fig.update_xaxes(tickmode="array", tickvals=list(range(1, 13)), ticktext=MONTH_NAMES)
    fig.update_layout(hovermode="x unified")
    style(fig, theme, height=420)

    insights = []
    if mode == "season":
        tot = dff.groupby("month").size()
        insights.append(f"Peak month: {MONTH_NAMES[tot.idxmax() - 1]}; quietest: "
                        f"{MONTH_NAMES[tot.idxmin() - 1]} ({tot.max() / tot.min() - 1:+.0%} difference).")
    else:
        by_m = dff.groupby("date").size()
        insights.append(f"Busiest month in selection: {by_m.idxmax():%B %Y} ({by_m.max():,} incidents).")
    return fig, insights


# ===========================================================================
# H1 - ANNOTATED HEATMAP: firearm share by region x year
# ===========================================================================
def fig_h1_heatmap(dff: pd.DataFrame, metric: str, theme: str):
    if dff.empty or dff["year"].nunique() < 2:
        return empty_figure(theme, "Select at least two years to compare"), []
    years = sorted(dff["year"].unique())
    share = dff.pivot_table(index="region", columns="year", values="firearm",
                            aggfunc="mean", observed=True) * 100
    share.loc["United States"] = dff.groupby("year")["firearm"].mean() * 100
    count = dff.pivot_table(index="region", columns="year", values="firearm",
                            aggfunc="size", observed=True)
    count.loc["United States"] = dff.groupby("year").size()
    rows = ["United States"] + [r for r in REGION_ORDER if r in share.index]
    share, count = share.reindex(rows)[years], count.reindex(rows)[years]

    if metric == "change":
        z = share.sub(share[years[0]], axis=0)
        scale, zmid = div_scale(theme), 0
        text, ctitle = z.round(1).map(lambda v: f"{v:+.1f}"), f"pp vs {years[0]}"
    elif metric == "count":
        z, scale, zmid = count, seq_scale(theme), None
        text, ctitle = count.map(lambda v: f"{v:,.0f}"), "Incidents"
    else:
        z, scale, zmid = share, seq_scale(theme), None
        text, ctitle = share.map(lambda v: f"{v:.0f}%"), "Firearm %"

    fig = go.Figure(go.Heatmap(
        z=z.values, x=[str(y) for y in years], y=rows, colorscale=scale, zmid=zmid,
        text=text.values, texttemplate="%{text}", textfont=dict(size=12),
        customdata=np.dstack([share.values, count.values]),
        xgap=2, ygap=2,
        colorbar=dict(title=dict(text=ctitle, side="right"), thickness=12),
        hovertemplate="<b>%{y}, %{x}</b><br>Firearm share: %{customdata[0]:.1f}%"
                      "<br>Incidents: %{customdata[1]:,.0f}<extra></extra>"))
    fig.update_yaxes(autorange="reversed", showgrid=False)
    fig.update_xaxes(showgrid=False, type="category", title="Year")
    style(fig, theme, height=430, legend=False)

    # Insight: compare the pre-surge year with the surge year when both exist
    a, b = (2019, 2021) if {2019, 2021} <= set(years) else (years[0], years[-1])
    delta = (share[b] - share[a]).drop("United States").dropna().sort_values()
    fa = dff[dff["year"].isin([a, b])].groupby(["year", "firearm"]).size().unstack()
    insights = []
    if not delta.empty:
        insights.append(f"{a} → {b}: firearm share rose most in the {delta.index[-1]} "
                        f"({delta.iloc[-1]:+.1f} pp) and least in the {delta.index[0]} "
                        f"({delta.iloc[0]:+.1f} pp).")
    if fa.shape == (2, 2):
        g_fa = fa.loc[b, True] / fa.loc[a, True] - 1
        g_ot = fa.loc[b, False] / fa.loc[a, False] - 1
        insights.append(f"Firearm homicides changed {g_fa:+.0%} vs {g_ot:+.0%} for all other "
                        f"weapons → the surge was {'firearm-driven' if g_fa > g_ot else 'not firearm-driven'}.")
    return fig, insights


# ===========================================================================
# H2 - SUNBURST: victim sex -> relationship -> weapon / circumstance
# ===========================================================================
def fig_h2_sunburst(dff: pd.DataFrame, outer: str, include_unknown: bool, theme: str):
    d = dff
    if not include_unknown:
        d = d[(d["victim_sex"] != UNKNOWN) & (d["rel_group"] != UNKNOWN) & (d[outer] != UNKNOWN)]
    if d.empty:
        return empty_figure(theme), []
    rel_colors = color_map(REL_ORDER, theme)
    sex_colors = {"Male": CHROME[theme]["ink2"], "Female": CHROME[theme]["muted"],
                  UNKNOWN: UNKNOWN_GRAY[theme]}
    ids, labels, parents, values, colors = [], [], [], [], []
    for sex, d1 in d.groupby("victim_sex", observed=True):
        ids.append(sex); labels.append(f"{sex} victims"); parents.append("")
        values.append(len(d1)); colors.append(sex_colors.get(sex, UNKNOWN_GRAY[theme]))
        for rel, d2 in d1.groupby("rel_group", observed=True):
            rid = f"{sex}/{rel}"
            ids.append(rid); labels.append(rel); parents.append(sex)
            values.append(len(d2)); colors.append(rel_colors[rel])
            for o, n in d2[outer].value_counts().items():
                if n == 0:
                    continue
                ids.append(f"{rid}/{o}"); labels.append(o); parents.append(rid)
                values.append(int(n)); colors.append(_rgba(rel_colors[rel], 0.55))
    fig = go.Figure(go.Sunburst(
        ids=ids, labels=labels, parents=parents, values=values, branchvalues="total",
        marker=dict(colors=colors, line=dict(color=CHROME[theme]["surface"], width=2)),
        textinfo="label+percent parent", insidetextorientation="radial",
        hovertemplate="<b>%{label}</b><br>%{value:,} incidents<br>"
                      "%{percentParent:.1%} of %{parent}<extra></extra>"))
    style(fig, theme, height=560, legend=False)
    fig.update_layout(margin=dict(l=8, r=8, t=8, b=8))

    insights = []
    known = d[(d["victim_sex"] != UNKNOWN) & (d["rel_group"] != UNKNOWN)]
    if not known.empty:
        tab = pd.crosstab(known["victim_sex"], known["rel_group"], normalize="index")
        if {"Female", "Male"} <= set(tab.index) and "Intimate partner" in tab.columns:
            f, m = tab.loc["Female", "Intimate partner"], tab.loc["Male", "Intimate partner"]
            insights.append(f"Intimate partners killed {_pct(f)} of female victims but only {_pct(m)} of "
                            f"male victims ({f / m:.1f}× higher)." if m > 0 else
                            f"Intimate partners killed {_pct(f)} of female victims.")
            top_m = tab.loc["Male"].idxmax()
            insights.append(f"For male victims the biggest group is “{top_m}” ({_pct(tab.loc['Male', top_m])}).")
    insights.append("Click a slice to zoom into it; click the center to zoom back out.")
    return fig, insights


# ===========================================================================
# H3 - PARALLEL CATEGORIES: relationship -> circumstance -> weapon flows
# ===========================================================================
def fig_h3_parcats(dff: pd.DataFrame, dims: list[str], include_unknown: bool, theme: str):
    dims = [d for d in (dims or []) if d in DIMENSIONS]
    if len(dims) < 2:
        return empty_figure(theme, "Choose at least two dimensions"), []
    d = dff
    if not include_unknown:
        for col in dims:
            d = d[d[col] != UNKNOWN]
    if d.empty:
        return empty_figure(theme), []
    g = d.groupby(dims, observed=True).size().reset_index(name="n")
    g = g[g["n"] > 0]

    color_dim = dims[0]
    order = DIMENSIONS[color_dim][1] + [UNKNOWN]
    present = [c for c in order if c in set(g[color_dim])]
    cmap = color_map(DIMENSIONS[color_dim][1], theme)
    idx = {c: i for i, c in enumerate(present)}
    k = len(present)
    scale = []
    for i, c in enumerate(present):        # stepped scale: one solid band per category
        scale += [[i / k, cmap[c]], [(i + 1) / k, cmap[c]]]

    dimensions = []
    for col in dims:
        label, cat_order = DIMENSIONS[col]
        cats = [c for c in cat_order + [UNKNOWN] if c in set(g[col])]
        dimensions.append(dict(values=g[col].astype(str), label=label,
                               categoryorder="array", categoryarray=cats))
    fig = go.Figure(go.Parcats(
        dimensions=dimensions, counts=g["n"],
        line=dict(color=g[color_dim].astype(str).map(idx).astype(float) + 0.5, colorscale=scale, cmin=0, cmax=k, shape="hspline"),
        hoveron="color", hoverinfo="count+probability", arrangement="freeform",
        labelfont=dict(size=14, color=CHROME[theme]["ink"]),
        tickfont=dict(size=12, color=CHROME[theme]["ink2"])))
    style(fig, theme, height=540, legend=False)
    fig.update_layout(margin=dict(l=110, r=110, t=40, b=24))

    insights = []
    known = d[d["rel_group"] != UNKNOWN] if "rel_group" in d else d
    if not known.empty and known["rel_group"].nunique() > 1:
        fa = known.groupby("rel_group", observed=True)["firearm"].mean().reindex(REL_ORDER).dropna()
        insights.append("Firearm share by relationship: " +
                        ", ".join(f"{r} {_pct(v)}" for r, v in fa.items()) + ".")
        kc = known[known["circ_group"] != UNKNOWN]
        if not kc.empty:
            fel = kc.groupby("rel_group", observed=True)["circ_group"].apply(
                lambda s: (s == "Felony-related").mean()).reindex(REL_ORDER).dropna()
            if "Stranger" in fel and "Family" in fel:
                insights.append(f"Felony-related circumstances: {_pct(fel['Stranger'])} of stranger "
                                f"killings vs {_pct(fel['Family'])} of family killings.")
            ip = kc[kc["rel_group"] == "Intimate partner"]["circ_group"]
            if len(ip):
                insights.append(f"{_pct((ip == 'Argument / brawl').mean())} of intimate-partner killings "
                                f"began as an argument or brawl.")
    insights.append("Drag the category boxes or whole axes to reorder them; hover a ribbon for counts.")
    return fig, insights


# ===========================================================================
# H4 - SPLIT VIOLIN: offender-minus-victim age gap by relationship / circumstance
# ===========================================================================
def fig_h4_violin(dff: pd.DataFrame, group_by: str, split_sex: bool, theme: str):
    order = DIMENSIONS[group_by][1]
    d = dff.dropna(subset=["age_gap"])
    d = d[d[group_by] != UNKNOWN]
    if split_sex:
        d = d[d["victim_sex"] != UNKNOWN]
    if d.empty:
        return empty_figure(theme), []
    if len(d) > 40_000:      # the browser draws the density; a fixed sample keeps it fast
        d = d.sample(40_000, random_state=42)

    fig = go.Figure()
    common = dict(box_visible=True, meanline_visible=True, points=False, spanmode="hard",
                  hoveron="violins+kde", scalemode="width", width=0.85)
    if split_sex:
        cmap = color_map(SEX_ORDER, theme)
        for sex, side in (("Male", "negative"), ("Female", "positive")):
            s = d[d["victim_sex"] == sex]
            fig.add_trace(go.Violin(x=s[group_by].astype(str), y=s["age_gap"], name=f"{sex} victim",
                                    side=side, line_color=cmap[sex], fillcolor=_rgba(cmap[sex], 0.45),
                                    legendgroup=sex, **common))
        fig.update_layout(violinmode="overlay", violingap=0.15)
    else:
        color = color_map(order, theme)
        for cat in order:
            s = d[d[group_by] == cat]
            if s.empty:
                continue
            fig.add_trace(go.Violin(x=s[group_by].astype(str), y=s["age_gap"], name=cat,
                                    line_color=color[cat], fillcolor=_rgba(color[cat], 0.45), **common))
    fig.add_hline(y=0, line_dash="dot", line_color=CHROME[theme]["muted"],
                  annotation_text="same age", annotation_position="top left",
                  annotation_font_color=CHROME[theme]["muted"])
    fig.update_xaxes(categoryorder="array", categoryarray=order, title=DIMENSIONS[group_by][0])
    fig.update_yaxes(title="Offender age − victim age (years)", range=[-80, 80])
    style(fig, theme, height=520, legend=True)

    full = dff.dropna(subset=["age_gap"])
    full = full[full[group_by] != UNKNOWN]
    iqr = full.groupby(group_by, observed=True)["age_gap"].agg(
        lambda s: s.quantile(0.75) - s.quantile(0.25)).reindex(order).dropna()
    insights = []
    if len(iqr) > 1:
        insights.append(f"Widest spread: {iqr.idxmax()} (middle 50% spans {iqr.max():.0f} years); "
                        f"narrowest: {iqr.idxmin()} ({iqr.min():.0f} years).")
    if group_by == "rel_group" and "Family" in iqr.index:
        fam = full[full["rel_group"] == "Family"]["age_gap"]
        insights.append(f"Family cases: {_pct((fam >= 15).mean())} have an offender 15+ years older "
                        f"(parent → child) and {_pct((fam <= -15).mean())} one 15+ years younger "
                        f"(child → parent) - two humps, not one.")
    return fig, insights


# ===========================================================================
# H5 - BUBBLE SCATTER: state firearm share vs victim age (+ least-squares line)
# ===========================================================================
H5_METRICS = {"age": "Median victim age (years)", "u25": "Victims under 25 (%)"}


def fig_h5_scatter(dff: pd.DataFrame, y_metric: str, min_n: int, theme: str):
    if dff.empty:
        return empty_figure(theme), []
    g = dff.groupby(["state", "region"], observed=True).agg(
        n=("firearm", "size"), fa=("firearm", "mean"), age=("victim_age", "median"),
        u25=("victim_age", lambda s: (s < 25).sum() / s.notna().sum() if s.notna().any() else np.nan)
    ).reset_index().dropna(subset=["fa", y_metric])
    g = g[g["n"] >= (min_n or 0)]
    if len(g) < 3:
        return empty_figure(theme, "Not enough states - lower the minimum-incidents slider"), []
    g["fa"] *= 100
    if y_metric == "u25":
        g["u25"] *= 100

    cmap = color_map(REGION_ORDER, theme)
    fig = px.scatter(g, x="fa", y=y_metric, size="n", color="region", symbol="region",
                     color_discrete_map=cmap, symbol_map=REGION_SYMBOLS, size_max=42,
                     text="state", category_orders={"region": REGION_ORDER},
                     custom_data=["state", "n"],
                     labels={"fa": "Firearm share of homicides (%)", y_metric: H5_METRICS[y_metric],
                             "region": "Region"})
    fig.update_traces(textposition="top center", textfont=dict(size=10, color=CHROME[theme]["ink2"]),
                      marker=dict(line=dict(color=CHROME[theme]["surface"], width=2), opacity=0.85,
                                  sizemin=7),
                      hovertemplate="<b>%{customdata[0]}</b><br>Firearm share: %{x:.1f}%"
                                    "<br>" + H5_METRICS[y_metric] + ": %{y:.1f}"
                                    "<br>Incidents: %{customdata[1]:,}<extra></extra>")
    # least-squares fit across all shown states
    slope, intercept = np.polyfit(g["fa"], g[y_metric], 1)
    xs = np.linspace(g["fa"].min(), g["fa"].max(), 50)
    r = np.corrcoef(g["fa"], g[y_metric])[0, 1]
    fig.add_trace(go.Scatter(x=xs, y=slope * xs + intercept, mode="lines", name=f"Trend (r = {r:.2f})",
                             line=dict(color=CHROME[theme]["muted"], dash="dash", width=2),
                             hoverinfo="skip"))
    style(fig, theme, height=540)

    per_region = []
    for reg in REGION_ORDER:
        s = g[g["region"] == reg]
        if len(s) >= 4:
            per_region.append(f"{reg} r = {np.corrcoef(s['fa'], s[y_metric])[0, 1]:.2f}")
    insights = [f"Across {len(g)} states, r = {r:.2f}: every +10 pp of firearm share goes with "
                f"{slope * 10:+.1f} on “{H5_METRICS[y_metric]}”."]
    if per_region:
        insights.append("Within each region: " + ", ".join(per_region) +
                        " - the link is not just a regional effect.")
    insights.append("Bubble size = number of incidents; shape and color = region.")
    return fig, insights


# ===========================================================================
# DATA TAB - HORIZONTAL BAR: share of missing values per column
# ===========================================================================
NICE = {"victim_age": "Victim age", "victim_sex": "Victim sex", "victim_race": "Victim race",
        "victim_ethnic": "Victim ethnicity", "offender_age": "Offender age",
        "offender_sex": "Offender sex", "offender_race": "Offender race",
        "weapon_group": "Weapon", "rel_group": "Relationship", "circ_group": "Circumstance"}


def fig_missing_bar(report: dict, theme: str):
    s = pd.Series(report["missing_pct"]).rename(index=NICE).sort_values()
    fig = go.Figure(go.Bar(
        x=s.values, y=s.index, orientation="h", marker_color=color_map(["x"], theme)["x"],
        marker_line_width=0, text=[f"{v:.1f}%" for v in s.values], textposition="outside",
        textfont=dict(color=CHROME[theme]["ink2"]),
        hovertemplate="%{y}: %{x:.1f}% missing<extra></extra>"))
    fig.update_xaxes(title="Records with the value missing / unknown (%)", range=[0, max(60, s.max() + 8)])
    fig.update_yaxes(showgrid=False)
    style(fig, theme, height=400, legend=False)
    fig.update_layout(bargap=0.35, margin=dict(l=130))
    return fig
