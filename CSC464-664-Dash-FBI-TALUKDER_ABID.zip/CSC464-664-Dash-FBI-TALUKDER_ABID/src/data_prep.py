"""
data_prep.py - Load, clean and structure the FBI Supplementary Homicide Report (SHR).

PIPELINE (runs automatically the first time app.py starts, or by hand with
`python -m src.data_prep`):

    data/shr-20XX.zip   (raw FBI "master files", fixed-width text, 2015-2024)
          |
          |  1. read every zip, split the text into 268-character records
          |  2. cut every record into columns using the FBI record layout
          |  3. decode FBI codes into readable labels (state, weapon, ...)
          |  4. clean: fix ages, drop negligent manslaughter + bad state codes
          |  5. derive analysis columns (firearm flag, age gap, age band, ...)
          v
    data/shr_clean.csv        one tidy row per homicide incident (cached)
    data/cleaning_report.json what was dropped and how much is missing

load_data() then reads the cached CSV, replaces missing category values with
the explicit label "Unknown" (so nothing silently disappears from charts) and
turns text columns into pandas "category" dtype, which makes filtering fast.
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
CLEAN_CSV = DATA_DIR / "shr_clean.csv"
REPORT_JSON = DATA_DIR / "cleaning_report.json"

UNKNOWN = "Unknown"

# ---------------------------------------------------------------------------
# 1. RECORD LAYOUT
# The master file is "fixed width": there are no commas; every field sits at
# a fixed character position of a 268-character line. Positions are
# (first, last), counted from 1, exactly as printed in the FBI record
# description. We read the incident header + the first victim/offender.
# ---------------------------------------------------------------------------
RECORD_LENGTH = 268
LAYOUT = {
    "state_code":      (2, 3),
    "ori":             (4, 10),
    "year2":           (14, 15),
    "population":      (16, 24),
    "agency":          (32, 55),
    "month":           (62, 63),
    "homicide_type":   (71, 71),
    "situation":       (75, 75),
    "victim_age":      (76, 77),
    "victim_sex":      (78, 78),
    "victim_race":     (79, 79),
    "victim_ethnic":   (80, 80),
    "offender_age":    (81, 82),
    "offender_sex":    (83, 83),
    "offender_race":   (84, 84),
    "offender_ethnic": (85, 85),
    "weapon":          (86, 87),
    "relationship":    (88, 89),
    "circumstance":    (90, 91),
}

# ---------------------------------------------------------------------------
# 2. CODE BOOKS - FBI codes -> readable labels. Codes that mean "unknown"
#    (U, 00, 99, UN) are deliberately left out so they become missing (NaN).
# ---------------------------------------------------------------------------
STATE = {
    "01": "AL", "02": "AZ", "03": "AR", "04": "CA", "05": "CO", "06": "CT",
    "07": "DE", "08": "DC", "09": "FL", "10": "GA", "11": "ID", "12": "IL",
    "13": "IN", "14": "IA", "15": "KS", "16": "KY", "17": "LA", "18": "ME",
    "19": "MD", "20": "MA", "21": "MI", "22": "MN", "23": "MS", "24": "MO",
    "25": "MT", "26": "NE", "27": "NV", "28": "NH", "29": "NJ", "30": "NM",
    "31": "NY", "32": "NC", "33": "ND", "34": "OH", "35": "OK", "36": "OR",
    "37": "PA", "38": "RI", "39": "SC", "40": "SD", "41": "TN", "42": "TX",
    "43": "UT", "44": "VT", "45": "VA", "46": "WA", "47": "WV", "48": "WI",
    "49": "WY", "50": "AK", "51": "HI",
}

REGIONS = {  # U.S. Census Bureau regions
    "Northeast": "CT ME MA NH RI VT NJ NY PA",
    "Midwest":   "IL IN MI OH WI IA KS MN MO NE ND SD",
    "South":     "DE DC FL GA MD NC SC VA WV AL KY MS TN AR LA OK TX",
    "West":      "AZ CO ID MT NV NM UT WY AK CA HI OR WA",
}
REGION = {s: r for r, states in REGIONS.items() for s in states.split()}

SEX = {"M": "Male", "F": "Female"}
RACE = {"W": "White", "B": "Black", "I": "American Indian",
        "A": "Asian", "P": "Pacific Islander"}
ETHNIC = {"H": "Hispanic", "N": "Not Hispanic"}

WEAPON_GROUP = {
    "11": "Other firearm", "12": "Handgun", "13": "Other firearm",
    "14": "Other firearm", "15": "Other firearm",
    "20": "Knife", "30": "Blunt object", "40": "Hands or feet",
    "50": "Other", "55": "Other", "60": "Other", "65": "Other",
    "70": "Other", "75": "Other", "80": "Other", "85": "Other", "90": "Other",
}
FIREARM_CODES = {"11", "12", "13", "14", "15"}

REL_GROUP = {c: g for g, codes in {
    "Intimate partner": "HU WI CH CW BF GF XH XW HO",
    "Family":           "MO FA SO DA BR SI IL SF SM SS SD OF",
    "Acquaintance":     "NE AQ EE ER FR OK",
    "Stranger":         "ST",
}.items() for c in codes.split()}

CIRC_GROUP = {c: g for g, codes in {
    "Felony-related":   "02 03 05 06 07 09 10 17 18 19 26 70",
    "Argument / brawl": "40 42 43 44 45",
    "Gang-related":     "46 47",
    "Other":            "32 41 48 49 60 80 81",
}.items() for c in codes.split()}

# Display orders (also used to keep colors fixed per category)
WEAPON_ORDER = ["Handgun", "Other firearm", "Knife", "Blunt object", "Hands or feet", "Other"]
REL_ORDER = ["Intimate partner", "Family", "Acquaintance", "Stranger"]
CIRC_ORDER = ["Felony-related", "Argument / brawl", "Gang-related", "Other"]
REGION_ORDER = ["Northeast", "Midwest", "South", "West"]
SEX_ORDER = ["Male", "Female"]
AGE_BANDS = [(-1, 12, "0-12"), (12, 17, "13-17"), (17, 24, "18-24"), (24, 34, "25-34"),
             (34, 49, "35-49"), (49, 64, "50-64"), (64, 200, "65+")]
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# Columns whose missing values we report on and label "Unknown"
CATEGORY_COLS = ["victim_sex", "victim_race", "victim_ethnic", "offender_sex",
                 "offender_race", "weapon_group", "rel_group", "circ_group"]
REPORT_COLS = ["victim_age", "victim_sex", "victim_race", "victim_ethnic",
               "offender_age", "offender_sex", "offender_race",
               "weapon_group", "rel_group", "circ_group"]


# ---------------------------------------------------------------------------
# 3. READ THE RAW FILES
# ---------------------------------------------------------------------------
def _split_records(raw_bytes: bytes) -> list[str]:
    """Turn the bytes of one master file into a list of text records."""
    text = raw_bytes.decode("latin-1")
    lines = [ln for ln in text.splitlines() if ln.strip()]
    # some master files have no line breaks at all -> cut every 268 characters
    if len(lines) == 1 and len(lines[0]) > 2 * RECORD_LENGTH:
        one = lines[0]
        lines = [one[i:i + RECORD_LENGTH] for i in range(0, len(one), RECORD_LENGTH)]
    return [ln for ln in lines if len(ln) >= 98]   # shorter lines are not records


def read_raw_records(data_dir: Path = DATA_DIR) -> list[str]:
    records: list[str] = []
    for path in sorted(data_dir.glob("shr-*.zip")):
        with zipfile.ZipFile(path) as z:
            for member in z.namelist():
                if member.lower().endswith((".pdf", ".doc", ".docx", ".xlsx", ".xls", "/")):
                    continue                     # skip documentation inside the zip
                recs = _split_records(z.read(member))
                print(f"  {path.name} -> {member}: {len(recs):,} records")
                records += recs
    if not records:
        raise SystemExit(f"No SHR zip files found in {data_dir}. "
                         "Download them from https://cde.ucr.cjis.gov (Master Files -> SHR).")
    return records


def parse(records: list[str]) -> pd.DataFrame:
    """Cut every record into columns using LAYOUT."""
    cols = {name: [r[a - 1:b].strip() for r in records] for name, (a, b) in LAYOUT.items()}
    return pd.DataFrame(cols)


def _clean_age(col: pd.Series) -> pd.Series:
    """FBI age codes: NB = newborn, BB = under 1 year -> 0;  00 = unknown -> NaN."""
    age = pd.to_numeric(col, errors="coerce")
    age = age.mask(col == "00")
    age = age.mask(col.isin(["NB", "BB"]), 0)
    return age


# ---------------------------------------------------------------------------
# 4 + 5. CLEAN AND DERIVE
# ---------------------------------------------------------------------------
def clean(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    report: dict = {"rows_read": int(len(raw))}

    df = pd.DataFrame()
    yy = pd.to_numeric(raw["year2"], errors="coerce")
    df["year"] = np.where(yy >= 60, 1900 + yy, 2000 + yy)          # 2-digit -> 4-digit year
    df["month"] = pd.to_numeric(raw["month"], errors="coerce")
    df["state"] = raw["state_code"].map(STATE)
    df["region"] = df["state"].map(REGION)
    df["agency"] = raw["agency"]
    df["homicide_type"] = raw["homicide_type"]

    df["victim_age"] = _clean_age(raw["victim_age"])
    df["victim_sex"] = raw["victim_sex"].map(SEX)
    df["victim_race"] = raw["victim_race"].map(RACE)
    df["victim_ethnic"] = raw["victim_ethnic"].map(ETHNIC)
    df["offender_age"] = _clean_age(raw["offender_age"])
    df["offender_sex"] = raw["offender_sex"].map(SEX)
    df["offender_race"] = raw["offender_race"].map(RACE)

    df["weapon_group"] = raw["weapon"].map(WEAPON_GROUP)
    df["firearm"] = raw["weapon"].isin(FIREARM_CODES)
    df["rel_group"] = raw["relationship"].map(REL_GROUP)
    df["circ_group"] = raw["circumstance"].map(CIRC_GROUP)

    # --- row filters (each one counted for the report) ---------------------
    is_murder = df["homicide_type"] == "A"          # A = murder / non-negligent manslaughter
    report["dropped_negligent_manslaughter"] = int((~is_murder).sum())
    df = df[is_murder]

    bad = df["state"].isna() | df["month"].isna() | ~df["month"].between(1, 12)
    report["dropped_bad_state_or_month"] = int(bad.sum())   # territories, corrupt codes
    df = df[~bad].copy()
    df["year"] = df["year"].astype(int)
    df["month"] = df["month"].astype(int)

    # impossible ages (FBI caps ages at 99 = "99 or older")
    for col in ("victim_age", "offender_age"):
        df.loc[~df[col].between(0, 99), col] = np.nan

    # --- derived analysis columns -------------------------------------------
    df["weapon_class"] = np.where(df["firearm"], "Firearm", "Other weapon")
    df["age_gap"] = df["offender_age"] - df["victim_age"]          # + = offender older
    bins = [b[0] for b in AGE_BANDS] + [AGE_BANDS[-1][1]]
    df["victim_age_band"] = pd.cut(df["victim_age"], bins=bins,
                                   labels=[b[2] for b in AGE_BANDS]).astype("object")
    df = df.drop(columns=["homicide_type"]).reset_index(drop=True)

    report["rows_kept"] = int(len(df))
    report["years"] = [int(df["year"].min()), int(df["year"].max())]
    report["exact_duplicate_rows"] = int(df.duplicated().sum())  # kept: separate incidents can look identical
    report["missing_pct"] = {c: round(float(df[c].isna().mean() * 100), 2) for c in REPORT_COLS}
    return df, report


def build_clean_data() -> tuple[pd.DataFrame, dict]:
    """Run the whole raw -> clean pipeline and cache the results on disk."""
    print("Building clean dataset from raw FBI SHR master files ...")
    df, report = clean(parse(read_raw_records()))
    df.to_csv(CLEAN_CSV, index=False)
    REPORT_JSON.write_text(json.dumps(report, indent=2))
    print(f"  rows read {report['rows_read']:,} -> rows kept {report['rows_kept']:,}")
    print(f"  saved {CLEAN_CSV.name} and {REPORT_JSON.name}")
    return df, report


# ---------------------------------------------------------------------------
# LOAD FOR THE DASHBOARD
# ---------------------------------------------------------------------------
def _cache_is_fresh() -> bool:
    if not (CLEAN_CSV.exists() and REPORT_JSON.exists()):
        return False
    newest_raw = max((p.stat().st_mtime for p in DATA_DIR.glob("shr-*.zip")), default=0)
    return CLEAN_CSV.stat().st_mtime >= newest_raw


def load_data() -> tuple[pd.DataFrame, dict]:
    """Return the analysis-ready DataFrame and the cleaning report."""
    if _cache_is_fresh():
        df = pd.read_csv(CLEAN_CSV, low_memory=False)
        report = json.loads(REPORT_JSON.read_text())
    else:
        df, report = build_clean_data()

    # Missing categories become an explicit "Unknown" level, so charts can
    # show or hide them on purpose instead of dropping rows silently.
    for col in CATEGORY_COLS + ["victim_age_band"]:
        df[col] = df[col].fillna(UNKNOWN)
    for col in CATEGORY_COLS + ["state", "region", "weapon_class", "victim_age_band", "agency"]:
        df[col] = df[col].astype("category")
    df["firearm"] = df["firearm"].astype(bool)
    df["date"] = pd.to_datetime(dict(year=df["year"], month=df["month"], day=1))
    return df, report


if __name__ == "__main__":       # python -m src.data_prep  -> force a rebuild
    _df, _report = build_clean_data()
    print(json.dumps(_report, indent=2))
