"""
callbacks.py - All interactivity.

A Dash *callback* is a normal Python function that Dash calls automatically
whenever one of its Input components changes (a slider moves, a dropdown
changes, a map is clicked ...). Whatever the function returns is written into
its Output components (a figure, some text ...). That is the whole trick.

Flow of data:

  sidebar filters ──► filtered(...) (cached) ──► every chart callback ──► figure + insight text
        ▲                                                     │
        └──────── map click / reset button ◄──────────────────┘
"""
from __future__ import annotations

from functools import lru_cache

import pandas as pd
from dash import Input, Output, State, ctx, dcc, html, no_update

from . import charts
from .data_prep import REGION, REGION_ORDER

# The six global filters - every chart listens to all of them
FILTERS = [
    Input("year-slider", "value"),
    Input("region-check", "value"),
    Input("state-dd", "value"),
    Input("weapon-dd", "value"),
    Input("sex-check", "value"),
    Input("age-slider", "value"),
]
THEME = Input("theme-store", "data")


def register_callbacks(app, df: pd.DataFrame, report: dict) -> None:

    # -----------------------------------------------------------------------
    # Filtering, memoised: the same filter combination is computed only once
    # even though ~8 callbacks ask for it at the same time.
    # -----------------------------------------------------------------------
    @lru_cache(maxsize=64)
    def _filter(years, regions, states, weapons, sexes, ages) -> pd.DataFrame:
        m = df["year"].between(*years)
        m &= df["region"].isin(regions)
        if states:
            m &= df["state"].isin(states)
        if weapons:
            m &= df["weapon_group"].isin(weapons)
        m &= df["victim_sex"].isin(sexes)
        if tuple(ages) != (0, 99):       # full range = keep unknown ages too
            m &= df["victim_age"].between(*ages)
        return df[m]

    def filtered(years, regions, states, weapons, sexes, ages) -> pd.DataFrame:
        # lists are not hashable -> turn them into tuples for the cache
        return _filter(tuple(years or (0, 9999)), tuple(sorted(regions or [])),
                       tuple(sorted(states or [])), tuple(sorted(weapons or [])),
                       tuple(sorted(sexes or [])), tuple(ages or (0, 99)))

    def bullets(lines):
        return [html.Li(t) for t in lines]

    # -----------------------------------------------------------------------
    # Theme toggle (light / dark). The choice is remembered in the browser.
    # -----------------------------------------------------------------------
    @app.callback(Output("theme-store", "data"), Input("theme-btn", "n_clicks"),
                  State("theme-store", "data"), prevent_initial_call=True)
    def toggle_theme(_, current):
        return "dark" if current == "light" else "light"

    @app.callback(Output("app-root", "className"), Output("theme-btn", "children"), THEME)
    def apply_theme(theme):
        return f"theme-{theme}", ("☀ Light" if theme == "dark" else "☾ Dark")

    # Clientside (runs in the browser, no server round-trip): also stamp the theme
    # on <html>, so pop-up dropdown menus outside #app-root are themed too.
    app.clientside_callback(
        "function(theme){ document.documentElement.dataset.theme = theme; return theme; }",
        Output("theme-btn", "title"), THEME)

    # -----------------------------------------------------------------------
    # Chained dropdown: only offer states that belong to the ticked regions
    # -----------------------------------------------------------------------
    @app.callback(Output("state-dd", "options"), Input("region-check", "value"))
    def state_options(regions):
        return sorted(s for s, r in REGION.items() if r in (regions or []))

    # -----------------------------------------------------------------------
    # Map click toggles a state; Reset restores every filter
    # -----------------------------------------------------------------------
    @app.callback(
        Output("year-slider", "value"), Output("region-check", "value"),
        Output("state-dd", "value"), Output("weapon-dd", "value"),
        Output("sex-check", "value"), Output("age-slider", "value"),
        Input("reset-btn", "n_clicks"), Input("map-graph", "clickData"),
        State("state-dd", "value"), State("region-check", "value"),
        prevent_initial_call=True)
    def reset_or_click(_, click, states, regions):
        if ctx.triggered_id == "reset-btn":
            y0, y1 = int(df["year"].min()), int(df["year"].max())
            return [y0, y1], REGION_ORDER, [], [], ["Male", "Female", "Unknown"], [0, 99]
        if click and click.get("points"):
            st = click["points"][0].get("location")
            states = list(states or [])
            states = [s for s in states if s != st] if st in states else states + [st]
            regions = list(regions or [])
            if st and REGION.get(st) not in regions:    # make sure its region is ticked
                regions.append(REGION[st])
            return no_update, regions, states, no_update, no_update, no_update
        return (no_update,) * 6

    # -----------------------------------------------------------------------
    # KPI cards + "showing N of M" summary
    # -----------------------------------------------------------------------
    @app.callback(Output("kpi-row", "children"), Output("filter-summary", "children"), *FILTERS)
    def update_kpis(*f):
        dff = filtered(*f)
        cards = [html.Div([html.Div(k["label"], className="kpi-label"),
                           html.Div(k["value"], className="kpi-value"),
                           html.Div(k["sub"], className="kpi-sub")], className="kpi")
                 for k in charts.kpis(dff, df)]
        summary = [html.Strong(f"{len(dff):,}"), f" of {len(df):,} incidents selected"]
        return cards, summary

    # -----------------------------------------------------------------------
    # Download the currently filtered rows as CSV
    # -----------------------------------------------------------------------
    @app.callback(Output("download", "data"), Input("download-btn", "n_clicks"),
                  *[State(i.component_id, i.component_property) for i in FILTERS],
                  prevent_initial_call=True)
    def download(_, *f):
        dff = filtered(*f).drop(columns=["date"])
        return dcc.send_data_frame(dff.to_csv, "fbi_homicides_filtered.csv", index=False)

    # -----------------------------------------------------------------------
    # One callback per chart. Pattern: filter -> build figure -> return.
    # -----------------------------------------------------------------------
    @app.callback(Output("map-graph", "figure"), Output("map-graph-insight", "children"),
                  *FILTERS, Input("map-metric", "value"), THEME)
    def update_map(*args):
        *f, metric, theme = args
        # The map ignores the State filter (so every state stays clickable) and
        # outlines the selected states in gold instead.
        map_df = filtered(f[0], f[1], [], *f[3:])
        fig, ins = charts.fig_map(map_df, metric, f[2], theme)
        return fig, bullets(ins)

    @app.callback(Output("trend-graph", "figure"), Output("trend-graph-insight", "children"),
                  *FILTERS, Input("trend-mode", "value"), THEME)
    def update_trend(*args):
        *f, mode, theme = args
        fig, ins = charts.fig_trend(filtered(*f), mode, theme)
        return fig, bullets(ins)

    @app.callback(Output("h1-graph", "figure"), Output("h1-graph-insight", "children"),
                  *FILTERS, Input("h1-metric", "value"), THEME)
    def update_h1(*args):
        *f, metric, theme = args
        fig, ins = charts.fig_h1_heatmap(filtered(*f), metric, theme)
        if f[3]:
            ins.append("Note: a Weapon filter is active, which makes the firearm share trivial here.")
        return fig, bullets(ins)

    @app.callback(Output("h2-graph", "figure"), Output("h2-graph-insight", "children"),
                  *FILTERS, Input("h2-outer", "value"), Input("h2-unknown", "value"), THEME)
    def update_h2(*args):
        *f, outer, unknown, theme = args
        fig, ins = charts.fig_h2_sunburst(filtered(*f), outer, bool(unknown), theme)
        return fig, bullets(ins)

    @app.callback(Output("h3-graph", "figure"), Output("h3-graph-insight", "children"),
                  *FILTERS, Input("h3-dims", "value"), Input("h3-unknown", "value"), THEME)
    def update_h3(*args):
        *f, dims, unknown, theme = args
        fig, ins = charts.fig_h3_parcats(filtered(*f), dims, bool(unknown), theme)
        return fig, bullets(ins)

    @app.callback(Output("h4-graph", "figure"), Output("h4-graph-insight", "children"),
                  *FILTERS, Input("h4-group", "value"), Input("h4-split", "value"), THEME)
    def update_h4(*args):
        *f, group_by, split, theme = args
        fig, ins = charts.fig_h4_violin(filtered(*f), group_by, bool(split), theme)
        return fig, bullets(ins)

    @app.callback(Output("h5-graph", "figure"), Output("h5-graph-insight", "children"),
                  *FILTERS, Input("h5-y", "value"), Input("h5-min", "value"), THEME)
    def update_h5(*args):
        *f, y_metric, min_n, theme = args
        fig, ins = charts.fig_h5_scatter(filtered(*f), y_metric, min_n, theme)
        return fig, bullets(ins)

    @app.callback(Output("missing-graph", "figure"), THEME)
    def update_missing(theme):
        return charts.fig_missing_bar(report, theme)
