"""
theme.py - One place for every color and the shared Plotly styling.

Rules followed:
* Categorical colors are assigned to a category ONCE and never change when
  filters change (e.g. "Stranger" is always the same yellow).
* Sequential data (counts, shares) uses one blue hue, light -> dark.
* Diverging data (change up / down) uses blue <-> red with a gray midpoint.
* Dark mode uses its own, re-stepped colors - not an automatic inversion.
"""
from __future__ import annotations

import plotly.graph_objects as go

# Categorical slots, in fixed order (validated colorblind-safe order)
SLOTS = {
    "light": ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"],
    "dark":  ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"],
}
UNKNOWN_GRAY = {"light": "#a9a7a0", "dark": "#6b6a64"}

CHROME = {
    "light": dict(surface="#fcfcfb", ink="#0b0b0b", ink2="#52514e", muted="#898781",
                  grid="#e1e0d9", axis="#c3c2b7", mid="#f0efec"),
    "dark":  dict(surface="#1a1a19", ink="#f0efec", ink2="#c3c2b7", muted="#898781",
                  grid="#2c2c2a", axis="#383835", mid="#383835"),
}

SEQ_BLUE = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]

FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'


def seq_scale(theme: str) -> list:
    """Sequential blue scale: 'low' always recedes toward the page surface
    (pale on light mode, dark navy on dark mode); 'high' always stands out."""
    steps = SEQ_BLUE if theme == "light" else ["#1c2a3d", "#184f95", "#256abf", "#3987e5",
                                                 "#6da7ec", "#9ec5f4", "#cde2fb"]
    n = len(steps) - 1
    return [[i / n, c] for i, c in enumerate(steps)]


def div_scale(theme: str) -> list:
    """Diverging blue (down) <-> gray (no change) <-> red (up)."""
    mid = CHROME[theme]["mid"]
    return [[0, "#184f95"], [0.25, "#6da7ec"], [0.5, mid], [0.75, "#ec8a89"], [1, "#b42f2f"]]


def color_map(categories: list[str], theme: str) -> dict:
    """Map categories (in their fixed order) to slots; 'Unknown' is always gray."""
    slots = SLOTS[theme]
    cmap = {c: slots[i % len(slots)] for i, c in enumerate(c for c in categories if c != "Unknown")}
    cmap["Unknown"] = UNKNOWN_GRAY[theme]
    return cmap


def style(fig: go.Figure, theme: str, *, height: int = 460, legend: bool = True) -> go.Figure:
    """Apply the shared look to any figure: transparent bg, quiet grid, our font."""
    c = CHROME[theme]
    fig.update_layout(
        height=height,
        font=dict(family=FONT, size=13, color=c["ink2"]),
        title_font=dict(size=15, color=c["ink"]),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=56, r=24, t=48, b=48),
        hoverlabel=dict(bgcolor=c["surface"], bordercolor=c["axis"],
                        font=dict(family=FONT, color=c["ink"], size=13)),
        showlegend=legend,
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=c["ink2"]),
                    orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        colorway=SLOTS[theme],
    )
    axis = dict(gridcolor=c["grid"], linecolor=c["axis"], zerolinecolor=c["axis"],
                tickfont=dict(color=c["muted"]), title_font=dict(color=c["ink2"]))
    fig.update_xaxes(**axis)
    fig.update_yaxes(**axis)
    return fig


def empty_figure(theme: str, message: str = "No incidents match the current filters") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=message, showarrow=False, font=dict(size=15, color=CHROME[theme]["muted"]))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    return style(fig, theme, legend=False)
